﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.SqlClient;
using System.Text;

/// <summary>
/// Summary description for ProjectClasses
/// </summary>
/// 

public class dbContacts
{
    public int pKey; // primary key
    [Required]
    [StringLength(25)]
    public string fName;
    [Required]
    [StringLength(25)]
    public string lName;
    [Required]
    [StringLength(35)]
    public string eMail;
    [StringLength(15)]
    public string Phone;
    [StringLength(75)]
    public string Comments;
}

public class dbSchedule
{
    [Required]
    public int pKey ; // primary key
    [Required]
    public string Description;
    [Required]
    public string fileName;
    [Required]
    public DateTime sendDate;
}

public class ProjectClasses
{
    public ProjectClasses()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public DataTable GetData(string conStr, string cmdSqlStr)
    {
        DataTable dataTable = new DataTable();
        SqlConnection dBConnection = new SqlConnection(conStr);

        try
        {
            using (SqlCommand sqlCmd = new SqlCommand(cmdSqlStr, dBConnection)
            {
                CommandType = CommandType.StoredProcedure
            })
            {
                dBConnection.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                sqlDa.Fill(dataTable);
            }
        }
        catch (System.Data.SqlClient.SqlException ex)
        {
            string msg = "Fetch Error:";
            msg += ex.Message;
            throw new Exception(msg);
        }
        finally
        {
            dBConnection.Close();
        }
        return dataTable;
    }
}

