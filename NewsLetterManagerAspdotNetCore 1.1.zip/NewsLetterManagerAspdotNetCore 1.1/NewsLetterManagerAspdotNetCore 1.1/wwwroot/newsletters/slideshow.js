// The JavaScript for the Slide Show application 

var $ = function (id) 
	{ 
	return document.getElementById(id); 
	}; 

window.onload = function () 
	{ 
	var listNode = $("image_list");
	var captionNode = $("caption"); 
	var subTitleNode = $("subtitle");	
	var imageNode = $("image"); 
	// Process image links 
	var links = listNode.getElementsByTagName("a"); 
	
	var i, linkNode, image; 
	
	var imageCache = []; 
	for ( i = 0; i < links.length; i++ ) 
	{ 
		linkNode = links[i]; 
		// Preload image and copy title properties 
		image = new Image(); 
		image.src = linkNode.getAttribute("href");
		image.title = linkNode.getAttribute("title"); 
		image.subtitle = linkNode.getAttribute("content");
		imageCache[imageCache.length] = image; 
	} 
		// Start slide show 
	var imageCounter = 0;
	var timer = setInterval( 
		function () 
			{ 
			imageCounter = (imageCounter + 1) % imageCache.length; 
			image = imageCache[imageCounter]; 
			imageNode.src = image.src; 
			captionNode.firstChild.nodeValue = image.title;
			subTitleNode.firstChild.nodeValue = image.subtitle;
			}, 
			10000);// 5000);
	};
	
		