﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;

namespace NewsLetterManagerAspdotNetCore_1._1.Pages
{
    public class ContactModel : PageModel
    {

        string strSqlConnect = Startup.JaysSonConfig.GetConnectionString("DefaultSqlConnectionString");
        //    Use on Linux when running MySql-Server
        //    string strSqlConnect = Startup.JaysSonConfig.GetConnectionString("MySqlConnectionString");
        public dbContacts dbContact = new dbContacts();
        private DataTable dataTable;

        Stack stkParam = new Stack();
        ProjectClasses pc = new ProjectClasses();
        [TempData]
        public int rowIndex {set; get;}
        [TempData]
        public int PrimaryKey { set; get; }

        public void OnGet()
        {
            if (dbContact == null) dbContact = new dbContacts();
            LoadContacts(dataTable);
        }

        public void OnPostPrevRec()
        {
            rowIndex--;
            {
                dataTable = pc.GetData(
                    strSqlConnect,
                    "qryStrContacts"
                    );
            }

            if (rowIndex < 0) rowIndex = 0;
            if (dataTable.Rows.Count > 0)
            {
                // Populate the TextBox with the first entry on page load

                dbContact.pKey = PrimaryKey= int.Parse(dataTable.Rows[rowIndex]["pKey"].ToString());
                dbContact.fName = dataTable.Rows[rowIndex]["fName"].ToString();
                dbContact.lName = dataTable.Rows[rowIndex]["lName"].ToString();
                dbContact.eMail = dataTable.Rows[rowIndex]["eMail"].ToString();
                dbContact.Phone = dataTable.Rows[rowIndex]["Phone"].ToString();
                dbContact.Comments = dataTable.Rows[rowIndex]["Comments"].ToString();
                dbContact.index = rowIndex;
                //query the DB on every postbacks
            }
        }

        public void OnPostAddRec(dbContacts dbContact)
        {
            if (dbContact == null) return;
            if (dbContact.fName == null) return;
            if (dbContact.lName == null) return;
            if (dbContact.eMail == null) return;

            stkParam.Push(dbContact.Comments);
            stkParam.Push(SqlDbType.VarChar);
            stkParam.Push("@Comments");
            stkParam.Push(dbContact.Phone);
            stkParam.Push(SqlDbType.VarChar);
            stkParam.Push("@Phone");
            stkParam.Push(dbContact.eMail);
            stkParam.Push(SqlDbType.VarChar);
            stkParam.Push("@eMail");
            stkParam.Push(dbContact.lName);
            stkParam.Push(SqlDbType.VarChar);
            stkParam.Push("@lName");
            stkParam.Push(dbContact.fName);
            stkParam.Push(SqlDbType.VarChar);
            stkParam.Push("@fName");

            processEvents("qryStrInsertContact");
        }

        public void OnPostUpdateRec(dbContacts dbContact)
        {
            if (dbContact == null) return;
            if (dbContact.fName == null) return;
            if (dbContact.lName == null) return;
            if (dbContact.eMail == null) return;

            stkParam.Push(dbContact.Comments);
            stkParam.Push(SqlDbType.VarChar);
            stkParam.Push("@Comments");
            stkParam.Push(dbContact.Phone);
            stkParam.Push(SqlDbType.VarChar);
            stkParam.Push("@Phone");
            stkParam.Push(dbContact.eMail);
            stkParam.Push(SqlDbType.VarChar);
            stkParam.Push("@eMail");
            stkParam.Push(dbContact.lName);
            stkParam.Push(SqlDbType.VarChar);
            stkParam.Push("@lName");
            stkParam.Push(dbContact.fName);
            stkParam.Push(SqlDbType.VarChar);
            stkParam.Push("@fName");
            stkParam.Push(dbContact.pKey.ToString());
            stkParam.Push(SqlDbType.Int);
            stkParam.Push("@pKey");

            processEvents("qryStrUpdateContact");
        }

        public void OnPostRemoveRec(dbContacts dbContact)
        {
            stkParam.Push(dbContact.pKey.ToString());
            stkParam.Push(SqlDbType.Int);
            stkParam.Push("@pKey");

            processEvents("qryStrContactRemove");

            dataTable =
                pc.GetData(
                strSqlConnect,
                "qryStrContacts"
                );
            if (rowIndex >= dataTable.Rows.Count) rowIndex = dataTable.Rows.Count - 1;
        }

        public void OnPostNextRec()
        {
            dataTable = pc.GetData(
                strSqlConnect,
                "qryStrContacts"
                 );

           rowIndex++;

           if (dataTable.Rows.Count > 0)
            {
                if (rowIndex >= dataTable.Rows.Count) rowIndex = (dataTable.Rows.Count - 1);
                // Populate the TextBox with the first entry on page load

                dbContact.pKey = PrimaryKey = int.Parse(dataTable.Rows[rowIndex]["pKey"].ToString());
                dbContact.fName = dataTable.Rows[rowIndex]["fName"].ToString();
                dbContact.lName = dataTable.Rows[rowIndex]["lName"].ToString();
                dbContact.eMail = dataTable.Rows[rowIndex]["eMail"].ToString();
                dbContact.Phone = dataTable.Rows[rowIndex]["Phone"].ToString();
                dbContact.Comments = dataTable.Rows[rowIndex]["Comments"].ToString();
                dbContact.index = rowIndex;
                //query the DB on every postbacks
            }
        }

        public void OnPostClearForm()
        {
            dbContact.fName = "";
            dbContact.lName = "";
            dbContact.eMail = "";
            dbContact.Phone = "";
            dbContact.Comments = "";
        }

        public void LoadContacts(DataTable dataTable)
        {
            rowIndex = 0;
            dataTable =
                pc.GetData(
                    strSqlConnect,
                    "qryStrContacts"
                    );
            GetContacts(rowIndex, dataTable);
        }

        private void GetContacts(int iRecord, DataTable dataTable)
        {

            if (dataTable.Rows.Count > 0)
            {
                // Populate the TextBox with the first entry on page load

                dbContact.pKey = int.Parse(dataTable.Rows[iRecord]["pKey"].ToString());
                dbContact.fName = dataTable.Rows[iRecord]["fName"].ToString();
                dbContact.lName = dataTable.Rows[iRecord]["lName"].ToString();
                dbContact.eMail = dataTable.Rows[iRecord]["eMail"].ToString();
                dbContact.Phone = dataTable.Rows[iRecord]["Phone"].ToString();
                dbContact.Comments = dataTable.Rows[iRecord]["Comments"].ToString();
                dbContact.index = iRecord;
            }
        }


        public void processEvents(string strEventCmd)
        {
            DataTable dataTable = new DataTable();
            SqlConnection dBConnection = new SqlConnection(strSqlConnect);

            try
            {
                using (SqlCommand sqlCmd = new SqlCommand(strEventCmd, dBConnection)
                {
                    CommandType = CommandType.StoredProcedure
                })
                {
                    while (0 < stkParam.Count)
                    {
                        // Passes - @Parameter, SqlDbType.VarChar, Parameter Value 
                        sqlCmd.Parameters.Add((string)stkParam.Pop(), (SqlDbType)stkParam.Pop()).Value = (string)stkParam.Pop()??"";
                    }

                    dBConnection.Open();
                    sqlCmd.ExecuteNonQuery();
                }
            }
            catch (Exception eMsg)
            {
                Console.WriteLine(DateTime.Now);
                Console.WriteLine(eMsg.ToString());
                for (int i = 0; i < 40; i++)
                    Console.Write("=");
            }
            finally
            {
                dBConnection.Close();
            }
        }

    }


    public class dbContacts
    {
        public int pKey { set; get; }
        [StringLength(35)]
        [Required(ErrorMessage = "First name is required.")]
        public string fName { set; get; }
        [Required(ErrorMessage = "Last name is required.")]
        [StringLength(50)]
        public string lName { set; get; }
        [Required(ErrorMessage = "Email address is required.")]
        [RegularExpression(@"^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*")]
        [StringLength(50)]
        public string eMail { set; get; }
        [StringLength(15)]
        public string Phone { set; get; }
        [StringLength(75)]
        public string Comments { set; get; }
        //  Field is used to track current record
        public int index;
    }
}
