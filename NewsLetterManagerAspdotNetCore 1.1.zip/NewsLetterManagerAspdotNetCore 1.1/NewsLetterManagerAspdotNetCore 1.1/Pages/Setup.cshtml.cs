using System;
using System.Data.SqlClient;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using System.IO;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace NewsLetterManagerAspdotNetCore_1._1.Pages
{
    [BindProperties]
    public class SetupModel : PageModel
    {
        private string strSqlConnect = Startup.JaysSonConfig.GetConnectionString("DefaultSqlConnectionString");
        private string UserAdmin = Startup.JaysSonConfig.GetSection("AuthenticationString")["DefaultUser"];
        private string PassCodeAdmin = Startup.JaysSonConfig.GetSection("AuthenticationString")["DefaultPasscode"];

        public string TextBoxResponse { set; get; }
        [BindProperty]
        public bool IsPostBack { set; get; }
        public bool IsAuthenticated { set; get; }

        public IHostingEnvironment _env;
        public SetupModel(IHostingEnvironment env)
        {
            _env = env;
        }

        public void OnGet()
        {
            IsPostBack = false;
            IsAuthenticated = false;
   
        }

        [BindProperty]
        public Authentication Auth { set; get; }
        public void OnPostAuthentication()
        {
            IsPostBack = true;

            if (OnValidation(Auth.User, Auth.Passcode))
                CreateDb();
            else
                TextBoxResponse = "Invalid User Credentials..";
        }

        public void OnPostContinue()
        {
            IsPostBack = true;
        }

        public void OnPostCanseled()
        {
            IsPostBack = true;
        }

        private bool OnValidation(string user, string passcode)
        {
            IsUserValid(user, passcode);
            if (IsAuthenticated)
                return true;
            else
                return false;
        }

        private void IsUserValid(string user, string passcode)
        {
            if ((user == UserAdmin) && (passcode == PassCodeAdmin))
                IsAuthenticated = true;
            else
                IsAuthenticated = false;
            // for testing only
            IsAuthenticated = true;
        }


        protected void CreateDb()
        {
            String queryString, tempStr;
            String sqlFile = "newsletterdb.sql";
            string strSqlConnect = Startup.JaysSonConfig.GetConnectionString("DefaultSqlConnectionString");
            string FilePath = _env.WebRootPath + "\\" + sqlFile;

            try
            {
                TextBoxResponse += "Executing Command:\n";
                TextBoxResponse += "Openning: ";
                TextBoxResponse += FilePath;
                TextBoxResponse += "\n\n";

                SqlConnection dBConnection = new SqlConnection(strSqlConnect);
                StreamReader dbCmdsFile = new StreamReader(FilePath);
    
                dBConnection.Open();

                while (!dbCmdsFile.EndOfStream)
                {
                    queryString = "";
                    tempStr = dbCmdsFile.ReadLine();
                    while (tempStr != "")
                    {
                        if (dbCmdsFile.EndOfStream) break;

                        queryString += tempStr;
                        tempStr = dbCmdsFile.ReadLine();
                    }

                    TextBoxResponse += "Executing Command:\n";
                    TextBoxResponse += queryString;
                    TextBoxResponse += "\n";


                    SqlCommand sqlCmd = new SqlCommand(queryString, dBConnection);
                    sqlCmd.ExecuteNonQuery();

                    TextBoxResponse += "-> Sucessful\n\n";

                }

                TextBoxResponse += "dbNewsLetter Build Complete\n";

                dbCmdsFile.Close();
                dBConnection.Close();
            }

            catch (System.Data.SqlClient.SqlException ex)
            {
                TextBoxResponse += "-> Last Comammand Failed\n";

                string msg = "Database Creation Error: ";
                msg += ex.Message;
                //    throw new Exception(msg);
            }

            finally
            {
                 // dBConnection.Close();
            }
        }

    }

    public class Authentication
    {
        [Required(ErrorMessage = "User is required.")]
        public string User { get; set; }
        [Required(ErrorMessage = "Pass Code is required.")]
        public string Passcode { get; set; }
    }
    
}

