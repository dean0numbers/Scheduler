using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;

namespace NewsLetterManagerAspdotNetCore_1._1.Pages
{
    public class SendMailModel : PageModel
    {
        private string strSqlConnect = Startup.JaysSonConfig.GetConnectionString("DefaultSqlConnectionString");
    //    private string strSqlConnect = Startup.JaysSonConfig.GetConnectionString("MySqlConnectionString");
        public string TextBoxResponse { set; get; }
        [BindProperty]
        public bool IsPostBack { set; get; } 

        public IHostingEnvironment _env;
        public SendMailModel(IHostingEnvironment env)
        {
            _env = env;
        }

        public void OnGet()
        {
            IsPostBack = false;
        }

        public void OnPostSend()
        {
            ProjectClasses pc = new ProjectClasses();
            IsPostBack = true;

            DataTable dataTableContacts =
                pc.GetData(
                    strSqlConnect,
                    "qryStrContacts"
                    );
            DataTable dataTableSchedules =
                pc.GetData(
                    strSqlConnect,
                    "qryStrSchedule");

            StringBuilder strNewsLetterContent = new StringBuilder();
            MailMessage mailObj = new MailMessage();


            if (dataTableSchedules.Rows.Count == 0)
            {
                TextBoxResponse = "No events scheduled for sending";
                return;
            }


            SmtpClient SMTPServer = new SmtpClient();
            SMTPServer.DeliveryMethod = SmtpDeliveryMethod.Network;
            NetworkCredential mailCredentials = new NetworkCredential("truex.dean@gmail.com", "FreeatLast");

            SMTPServer.Host = "smtp.gmail.com";
            SMTPServer.Port = 587;
            SMTPServer.EnableSsl = true;
            SMTPServer.UseDefaultCredentials = false;
            SMTPServer.Credentials = mailCredentials;


            //  Check to see if there Contacts to send to 
            if (dataTableSchedules.Rows.Count == 0)
            {
                TextBoxResponse = "There were no Contacts found in contact manager";
                return;
            }

            strNewsLetterContent.Append("<h1>Raspberry Pi Newletter</h1>");


            for (int i = 0; i < dataTableSchedules.Rows.Count; i++)
            {
                if (((DateTime)dataTableSchedules.Rows[i]["SendDate"]).Date <= DateTime.Now)
                {
                    Int32 pKey = ((Int32)dataTableSchedules.Rows[i]["pKey"]);
                    if (dataTableContacts.Rows.Count > 0)
                    {
                        string MailReceiver = dataTableContacts.Rows[0]["eMail"].ToString();

                        mailObj.From = new MailAddress("truex.dean@gmail.com"); //    From
                        mailObj.To.Add(MailReceiver); //     To
                        if (dataTableContacts.Rows.Count > 1)
                            for (int j = 1; j < dataTableContacts.Rows.Count; j++)
                            {
                                MailReceiver = dataTableContacts.Rows[j]["eMail"].ToString();
                                mailObj.Bcc.Add(MailReceiver);
                            }
                        mailObj.Subject = "Raspberry Pi News";   //     Subject 
                        mailObj.Body = strNewsLetterContent.ToString();    //     Body

                        string FileName = dataTableSchedules.Rows[i]["SendFile"].ToString();
                        string FilePath = _env.WebRootPath;
                        string FullPath = FilePath + "/newsletters/" + FileName;
         
                        mailObj.Attachments.Add(new Attachment(FullPath));
                        mailObj.SubjectEncoding = System.Text.Encoding.UTF8;
                        mailObj.BodyEncoding = System.Text.Encoding.UTF8;
                        mailObj.IsBodyHtml = true;
                        mailObj.Priority = MailPriority.Normal;

                        try
                        {
                            TextBoxResponse =
                                "Sending: " + dataTableSchedules.Rows[i]["SendFile"].ToString();

                            SMTPServer.Send(mailObj);

                            TextBoxResponse =
                                "Sent: " + dataTableSchedules.Rows[i]["SendFile"].ToString();

                            RemoveSentFromSchedule(pKey);
                        }
                        catch (Exception ex)
                        {
                            TextBoxResponse =
                                "Unable to Sent: " + dataTableSchedules.Rows[i]["SendFile"].ToString();
                            TextBoxResponse = ex.ToString();
                        }
                    }
                }
            }
        }


        private void RemoveSentFromSchedule(Int32 pKey)
        {
            SqlConnection dBConnection = new SqlConnection(strSqlConnect);
            string queryString =
                "DELETE FROM Schedule WHERE pKey = '" + pKey + "';";

            try
            {
                dBConnection.Open();
                SqlCommand sqlCmd = new SqlCommand(queryString, dBConnection);
                sqlCmd.ExecuteNonQuery();
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
                string msg = "Fetch Error:";
                msg += ex.Message;
                throw new Exception(msg);
            }
            finally
            {
                dBConnection.Close();
            }
        }
    }
}