using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;

namespace NewsLetterManagerAspdotNetCore_1._1.Pages
{
    [BindProperties]
    public class SchedulerModel : PageModel
    {
        string strSqlConnect = Startup.JaysSonConfig.GetConnectionString("DefaultSqlConnectionString");
        //   When using Linux and MySql Server
        //   string strSqlConnect = Startup.JaysSonConfig.GetConnectionString("MySqlConnectionString");
        
        public dbScheduleAdd dbSchedulesAdd = new dbScheduleAdd();
       
        public DataTable dataTable;
        ProjectClasses pc = new ProjectClasses();
        Stack stkParam = new Stack();

        public Boolean flagItem { set; get; }
        public Boolean flagFooter { set; get; }
        public Boolean flagFileIsNull { set; get; }
        public int idTag { set; get; }

        // Update Properties
        public string pKey { set; get; }
        [Required(ErrorMessage = "Description is required.")]
        public string Description { set; get; }
        public string fileName { set; get; }
        public DateTime sendDate { set; get; }


        public void OnGet()
        {
            flagItem = true;
            flagFooter = true;
            flagFileIsNull = true;
            idTag = -1;
            dataTable = pc.GetData(
                strSqlConnect,
                "qryStrSchedule"
                 );
        }

        public void OnPost()
        {
                // Your code goes here ..........
        }

        public void OnPostAddSchedule()
        {
            flagFooter = false;
            flagItem = true;
            flagFileIsNull = true;
            idTag = -1;

            dataTable = pc.GetData(
                strSqlConnect,
                "qryStrSchedule"
                );
        }

        public void OnPostSubmitSchedule(dbScheduleAdd dbSchedulesAdd)
        {
            string filePath = @"./wwwroot/newsletters/";
           
            flagFooter = true;
            flagItem = true;
            flagFileIsNull = true;


            try
            {
                string desc = dbSchedulesAdd.Description;
                string fileName = dbSchedulesAdd.fileName.FileName;
                string date = dbSchedulesAdd.sendDate.ToShortDateString();

                if (dbSchedulesAdd.fileName.Length > 0)
                {
                    fileName = Path.GetFileName(fileName);
                    using (var fileStream = new FileStream(filePath + fileName, FileMode.Create))
                    {
                        dbSchedulesAdd.fileName.CopyTo(fileStream);
                    }
                }

                else return;

                if (desc == null) return;

                stkParam.Push(date);
                stkParam.Push(SqlDbType.Date);
                stkParam.Push("@sendDate");
                stkParam.Push(fileName);
                stkParam.Push(SqlDbType.VarChar);
                stkParam.Push("@sendFile");
                stkParam.Push(desc);
                stkParam.Push(SqlDbType.VarChar);
                stkParam.Push("@Descript");

                processEvents("qryStrInsertSchedule");

                dataTable = pc.GetData(
                    strSqlConnect,
                    "qryStrSchedule"
                    );

                idTag = -1;
            }

            catch (Exception eMsg)
            {
                Console.WriteLine(DateTime.Now);
                Console.WriteLine(eMsg.ToString());
                for (int i = 0; i < 40; i++ )
                    Console.Write("=");
            }

            finally
            {
                dataTable = pc.GetData(
                    strSqlConnect,
                    "qryStrSchedule"
                    );
            }
        }

        public void OnPostCanSub()
        {
            flagFooter = true;
            flagItem = true;
            idTag = -1;

            dataTable = pc.GetData(
                strSqlConnect,
                "qryStrSchedule"
                );
        }

        public void OnPostSelect(int id)
        {
            flagItem = false;
            flagFooter = true;
            flagFileIsNull = true;
            idTag = id;

            if (dataTable == null)
                dataTable = pc.GetData(
                    strSqlConnect,
                    "qryStrSchedule"
                    );

            pKey = dataTable.Rows[id]["pKey"].ToString();
            Description = dataTable.Rows[id]["Descript"].ToString();
            fileName = dataTable.Rows[id]["sendFile"].ToString();
            sendDate = (DateTime)dataTable.Rows[id]["sendDate"];
        }

        public void OnPostRemove(int id)
        {
            flagFooter = true;
            flagItem = true;
            flagFileIsNull = true;
            
            dataTable = pc.GetData(
                strSqlConnect,
                "qryStrSchedule"
                );

            string pKey = dataTable.Rows[id]["pKey"].ToString();

            stkParam.Push(pKey);
            stkParam.Push(SqlDbType.Int);
            stkParam.Push("@pKey");

            processEvents("qryStrScheduleRemove");

            dataTable = pc.GetData(
                strSqlConnect,
                "qryStrSchedule"
                );

            id = idTag = -1;
        }

        public void OnPostUpdateSchedule()
        {
            flagFooter = true;
            flagItem = true;
            flagFileIsNull = true;

            if (Description == null) return;

            stkParam.Push(sendDate.ToShortDateString());
            stkParam.Push(SqlDbType.Date);
            stkParam.Push("@sendDate");
            stkParam.Push(fileName);
            stkParam.Push(SqlDbType.VarChar);
            stkParam.Push("@sendFile");
            stkParam.Push(Description);
            stkParam.Push(SqlDbType.VarChar);
            stkParam.Push("@Descript");

            stkParam.Push(pKey);
            stkParam.Push(SqlDbType.Int);
            stkParam.Push("@pKey");

            processEvents("qryStrUpdateSchedule");

            dataTable = pc.GetData(
                strSqlConnect,
                "qryStrSchedule"
                );

            idTag = -1;
        }

        public void OnPostCanselSelect()
        {
            flagFooter = true;
            flagItem = true;
            flagFileIsNull = true;
            idTag = -1;

            if (dataTable == null)
                dataTable = pc.GetData(
                    strSqlConnect,
                    "qryStrSchedule"
                    );
        }

  
        public void processEvents(string strEventCmd)
        {
            DataTable dataTable = new DataTable();
            SqlConnection dBConnection = new SqlConnection(strSqlConnect);

            try
            {
                using (SqlCommand sqlCmd = new SqlCommand(strEventCmd, dBConnection)
                {
                    CommandType = CommandType.StoredProcedure
                })
                {
                    while (0 < stkParam.Count)
                    {
                        // Passes - @Parameter, SqlDbType.VarChar, Parameter Value 
                        sqlCmd.Parameters.Add((string)stkParam.Pop(), (SqlDbType)stkParam.Pop()).Value = (string)stkParam.Pop() ?? "";
                    }

                    dBConnection.Open();
                    sqlCmd.ExecuteNonQuery();
                }
            }
            catch (Exception eMsg)
            {
                Console.WriteLine(DateTime.Now);
                Console.WriteLine(eMsg.ToString());
                for (int i = 0; i < 40; i++)
                    Console.Write("=");
            }
            finally
            {
                dBConnection.Close();
            }
        }

    }

    public class dbSchedule
    {
        [Required]
        public string pKey; // primary key
        [Required]
        public string Description;
        [Required]
        public string fileName;
        [Required]
        public DateTime sendDate;
    }

    public class dbScheduleAdd
    {
        [Required]
        public string Description { get; set; }
        [Required]
        public IFormFile fileName { get; set; }
        [Required]
        public DateTime sendDate { get; set; }
    }
}