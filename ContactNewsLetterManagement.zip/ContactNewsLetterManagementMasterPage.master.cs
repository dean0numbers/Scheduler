﻿using System;

public partial class ContactNewsLetterManagementMasterPage : System.Web.UI.MasterPage
{

    protected void Page_PreInit(object sender, EventArgs e)
    {

    }

    protected void Page_Init(object sender, EventArgs e)
    {

    }

    protected void Page_InitComplete(object sender, EventArgs e)
    {

    }

    protected void Page_Preload(object sender, EventArgs e)
    {

    }

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Page_LoadComplete(object sender, EventArgs e)
    {

    }

    protected void Page_PreRender(object sender, EventArgs e)
    {

    }

    protected void Page_PrerenderComplete(object sender, EventArgs e)
    {

    }

    protected void Page_Unload(object sender, EventArgs e)
    {

    }

    protected void Page_Error(object sender, EventArgs e)
    {

    }
}
